# Dark Eye Trader Android App

This Android Studio project packages the Dark Eye Trader website as an offline WebView app.

## Build APK
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. The debug APK will be under `app/build/outputs/apk/debug/`.

Package: `com.darkeyetrader.app`
App name: `Dark Eye Trader`
